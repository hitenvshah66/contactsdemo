package com.contacts.contactsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
