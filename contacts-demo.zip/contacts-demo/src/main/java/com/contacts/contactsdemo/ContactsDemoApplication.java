package com.contacts.contactsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactsDemoApplication.class, args);
	}

}
