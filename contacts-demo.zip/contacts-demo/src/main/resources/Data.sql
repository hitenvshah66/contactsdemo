insert into Contact(id,
			name,
		    email,
		    phone,
		    address,
		    city,
		    state,
		    zipcode,
		    user_name
)
values(1001,'hiten','hitenvshah@me.com','9145060045','156 Locust Ave','Cortlandt Manor','NY','10567','ADMIN');
insert into Contact(id,
			name,
		    email,
		    phone,
		    address,
		    city,
		    state,
		    zipcode,
		    user_name
)
values(1002,'jalpa','hitenvshah@me.com','9145060045','156 Locust Ave','Cortlandt Manor','NY','10567','USER');

insert into Contact(id,
			name,
		    email,
		    phone,
		    address,
		    city,
		    state,
		    zipcode,
		    user_name
)
values(1003,'kasish','hitenvshah@me.com','9145060045','156 Locust Ave','Cortlandt Manor','NY','10567','USER');

